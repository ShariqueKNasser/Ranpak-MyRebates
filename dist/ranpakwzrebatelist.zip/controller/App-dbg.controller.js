sap.ui.define([
    "ranpak/wz/rebatelist/controller/BaseController"
], function (BaseController) {
    "use strict";

    return BaseController.extend("ranpak.wz.rebatelist.controller.App", {
        onInit: function () {

        }
    });
});
